#!/bin/bash

if [ "$1" == "" ]; then
    exit
fi
if [ "$4" == "" ]; then 
    exit
fi

if [ "$4" == "7h1" ]; then
    partconfs="--partition=P100,TitanXx8,TitanXx8_slong --cpus-per-task=5"
elif [ "$4" == "7h1m" ]; then
    partconfs="--partition=M40x8,M40x8_slong --cpus-per-task=5"
elif [ "$4" == "7h1x" ]; then
    partconfs="--partition=P100,TitanXx8,TitanXx8_slong,M40x8,M40x8_slong --cpus-per-task=5"
elif [ "$4" == "7h2" ]; then
    partconfs="--partition=1080Ti,1080Ti_slong --cpus-per-task=2"
elif [ "$4" == "1h1x" ]; then
    partconfs="--partition=TitanXx8_short,P100,TitanXx8,TitanXx8_slong,M40x8_short,M40x8,M40x8_slong --cpus-per-task=5"
elif [ "$4" == "1h1" ]; then
    partconfs="--partition=TitanXx8_short,P100,TitanXx8,TitanXx8_slong --cpus-per-task=5"
elif [ "$4" == "1h1m" ]; then
    #partconfs="--partition=V100,P100 --cpus-per-task=5"
    partconfs="--partition=M40x8_short,M40x8,M40x8_slong --cpus-per-task=5"
    #partconfs="--partition=TitanXx8_short,TitanXx8,TitanXx8_slong --cpus-per-task=5"
elif [ "$4" == "1h2" ]; then
    partconfs="--partition=1080Ti_short,1080Ti,1080Ti_slong --cpus-per-task=2"
elif [ "$4" == "1h3" ]; then
    partconfs="--partition=1080Ti_dbg --cpus-per-task=8"
elif [ "$4" == "6d1" ]; then
    partconfs="--partition=TitanXx8_slong,TitanXx8_slong,M40x8_slong --cpus-per-task=5"
elif [ "$4" == "6d1m" ]; then
    partconfs="--partition=M40x8_slong --cpus-per-task=5"
elif [ "$4" == "6d2" ]; then
    partconfs="--partition=1080Ti_slong --cpus-per-task=2"
fi

param="$2"
suffix="$1.$3"; mkdir -p log; rm -f log/log.$suffix; 
cat train.py >log/log.$suffix
jn="att6reg"
if [ "$5" != "" ]; then
    jn="$5"
fi 
nohup srun --job-name=$jn $partconfs --gres=gpu:1 -n1 bash run.sh train.py $param 2>&1 >>log/log.$suffix &

