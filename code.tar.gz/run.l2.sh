#!/bin/bash

i=3
reg="l2"

datadir="/mnt/data/lixingjian/benchmark"
run(){
    da="$1"
    data="$2"
    pt="$3"
    if [ "$data" == "indoorCVPR_09" ]; then
        base="resnet50"
        bs=48
    else
        base="resnet101"
        bs=64
    fi
    if [ "$da" == "best" ]; then
        bs=48
    fi
    bash run.one.sh $data "--batch_size=$bs --base_model=$base --data_dir=$datadir/$data --reg_type=$reg --data_aug=$da" "$reg.$da.$i" $pt "s_$reg"
}

da="normal"
#run $da "Stanford_Dogs" 7h2
#run $da "Caltech30" 7h2
#run $da "Caltech60" 7h2
#run $da "indoorCVPR_09" 7h2

da="best"
run $da "Stanford_Dogs" 7h2
run $da "Caltech30" 7h2
run $da "Caltech60" 7h2
run $da "indoorCVPR_09" 7h2
