# -*- coding: utf-8 -*-
from __future__ import print_function, division

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torchvision import datasets, models, transforms
import torch.utils.model_zoo as model_zoo
from inceptionv4 import inceptionv4
import time
import sys
import random
import os
import copy
import argparse
import math
import pickle
import numpy as np
from torchnet import meter
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

parser = argparse.ArgumentParser(description = 'DELTA')
parser.add_argument('--data_dir')
parser.add_argument('--save_model', default = '')
parser.add_argument('--base_model', choices = ['resnet101', 'inceptionv4'], default = 'resnet101')
parser.add_argument('--image_size', type = int, default = 224)
parser.add_argument('--batch_size', type = int, default = 64)
parser.add_argument('--lr_scheduler', default = 'explr')
parser.add_argument('--lr_init', type = float, default = 0.01)
parser.add_argument('--alpha', type = float, default = 0.01)
parser.add_argument('--reg_type', choices = ['l2', 'l2_sp', 'fea_map', 'fea_map_w'], default = 'l2')
#data augmentation
parser.add_argument('--data_aug', choices = ['normal', 'best'])
parser.add_argument('--att_lr', type = float, default = 0.001)
parser.add_argument('--att_active', default = 'relu')
parser.add_argument('--att_fea', type = int, default = 100)
args = parser.parse_args()
print(args)

alpha = args.alpha
beta = 0.01
batch_size = args.batch_size
image_size = args.image_size
if args.base_model.startswith('inception'):
    crop_size = {299: 320}
else:
    crop_size = {224: 256}

resize = crop_size[image_size]
hflip = transforms.RandomHorizontalFlip()
rcrop = transforms.RandomCrop((image_size, image_size))
ccrop = transforms.CenterCrop((image_size, image_size))
totensor = transforms.ToTensor()
cnorm = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]) #mean and std for imagenet

def transform_compose_train():
    if args.data_aug == 'best':
        r = [transforms.Resize(resize), hflip, ccrop, rcrop, totensor, cnorm]
    elif args.data_aug == 'normal':
        r = [transforms.Resize((resize, resize)), hflip, rcrop, totensor, cnorm]
    return transforms.Compose(r)

def transform_compose_test():
    if args.data_aug == 'best':
        stack_crop = transforms.Lambda(lambda crops: torch.stack([cnorm(transforms.ToTensor()(crop)) for crop in crops]))
        r = [transforms.Resize(resize), transforms.TenCrop(args.image_size), stack_crop]
    elif args.data_aug == 'normal':
        r = [transforms.Resize((image_size, image_size)), ccrop, totensor, cnorm]
    return transforms.Compose(r)

data_transforms = {'train': transform_compose_train(), 'valid': transform_compose_test()}
set_names = list(data_transforms.keys())
image_datasets = {x: datasets.ImageFolder(os.path.join(args.data_dir, x),
                                          data_transforms[x])
                  for x in set_names}
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=batch_size,
                                             shuffle=True, num_workers=4)
              for x in set_names}
dataset_sizes = {x: len(image_datasets[x]) for x in set_names}
class_names = image_datasets['train'].classes
num_classes = len(class_names)
device = torch.device("cuda:0")

def get_base_model(base_name):
    if base_name == 'resnet50':
        model_fea = models.resnet50(pretrained = False, num_classes = 365)
        state_dict = torch.load('resnet50_places365_python36.pth.tar', pickle_module=pickle)['state_dict'] 
        state_dict_new = {}
        for k, v in state_dict.items():
            state_dict_new[k[len('module.'):]] = v
        model_fea.load_state_dict(state_dict_new)
    elif base_name == 'resnet34':
        model_fea = models.resnet34(pretrained = True)
    elif base_name == 'resnet101':
        model_fea = models.resnet101(pretrained = True)
    elif base_name == 'inceptionv4':
        model_fea = inceptionv4(pretrained = 'imagenet')
    return model_fea

model_source = get_base_model(args.base_model)
model_source.to(device)
for param in model_source.parameters():
    param.requires_grad = False
model_source.eval()

model_target = get_base_model(args.base_model)
if args.base_model == 'inceptionv4':
    model_target.last_linear = nn.Linear(1536, num_classes)
elif args.base_model == 'resnet101':
    model_target.fc = nn.Linear(2048, num_classes)
model_target.to(device)

layer_outputs_source = []
layer_outputs_target = []
def for_hook_source(module, input, output):
    layer_outputs_source.append(output)   
def for_hook_target(module, input, output): 
    layer_outputs_target.append(output)

fc_name = 'fc.'
hook_layers = ['layer1.2.conv3', 'layer2.3.conv3', 'layer3.22.conv3', 'layer4.2.conv3']
if args.base_model == 'resnet50':
    hook_layers[2] = 'layer3.5.conv3' 
elif args.base_model == 'resnet34':
    hook_layers = ['layer1.2.conv2', 'layer2.3.conv2', 'layer3.5.conv2', 'layer4.2.conv2']
elif args.base_model == 'inceptionv4':
    hook_layers = ['features.5', 'features.10', 'features.18']
    fc_name = 'last_linear.'

def register_hook(model, func):
    for name, layer in model.named_modules():
        if name in hook_layers:
            layer.register_forward_hook(func)
register_hook(model_source, for_hook_source)
register_hook(model_target, for_hook_target)

def classifier_l2(model):
    l2_cls = torch.tensor(0.).to(device)
    for name, param in model.named_parameters():
        if name.startswith(fc_name):
            l2_cls += torch.norm(param) ** 2
    return l2_cls

def get_param_values(model):
    feature_params = {}
    for name, param in model.named_parameters():
        feature_params[name] = param.clone().detach() 
    return feature_params

def param_l2_sp(model, param_dict):
    fea_loss = torch.tensor(0.).to(device)
    for name, param in model.named_parameters():
        if not name.startswith(fc_name):
            fea_loss += torch.norm(param - param_dict[name]) ** 2
    return fea_loss

def feature_map_l2_sp(inputs):
    _ = model_source(inputs)
    fea_loss = torch.tensor(0.).to(device)
    for fm_src, fm_tgt in zip(layer_outputs_source, layer_outputs_target):
        fm_src = fm_src.detach()
        b, c, h, w = fm_src.shape
        fea_loss += (torch.norm(fm_tgt - fm_src) ** 2)
    return fea_loss

def flatten_outputs(fea):
    return torch.reshape(fea, (fea.shape[0], fea.shape[1], fea.shape[2] * fea.shape[3]))

def attentioned_feature_map_l2_sp(inputs, attmodels):
    _ = model_source(inputs)
    fea_loss = torch.tensor(0.).to(device)
    assert len(attmodels) == len(layer_outputs_source)
    for (m, _, _), fm_src, fm_tgt in zip(attmodels, layer_outputs_source, layer_outputs_target):
        fm_src = fm_src.detach()
        b, c, h, w = fm_src.shape
        weights = m(fm_src)
        fm_src = flatten_outputs(fm_src)
        fm_tgt = flatten_outputs(fm_tgt)
        div_norm = h * w
        #div_norm = torch.mean(torch.norm(fm_src, 2, 2))
        loss = torch.norm(fm_tgt - fm_src, 2, 2)
        loss = c * torch.mul(weights, loss ** 2) / div_norm
        fea_loss += torch.sum(loss)
    return fea_loss

class AttentionMap(nn.Module):
    def __init__(self, input_size, channels):
        super(AttentionMap, self).__init__()
        if args.att_fea < 10:
            fea_size = int(10 * input_size / args.att_fea)
        else:
            fea_size = args.att_fea
        self.fc1 = nn.Linear(input_size * input_size, fea_size)
        self.fc2 = nn.Linear(fea_size, 1)
        self.bn = nn.BatchNorm2d(channels)
        self.active = nn.ReLU() if args.att_active == 'relu' else nn.Tanh()

    def forward(self, x):
        x = self.bn(x)
        x = x.reshape((x.shape[0], x.shape[1], x.shape[2] * x.shape[3]))
        x = F.dropout(x)
        x = self.fc1(x)
        x = self.active(x)
        x = self.fc2(x)
        x = x.squeeze(2)
        x = F.softmax(x, dim = 1)
        return x

fea_map_sizes = [(56, 256), (28, 512), (14, 1024), (7, 2048)]
if args.base_model == 'resnet34':
    fea_map_sizes = [(56, 64), (28, 128), (14, 256), (7, 512)]
elif args.base_model == 'inceptionv4':
    fea_map_sizes = [(35, 384), (17, 1024), (8, 1536)]
attention_models = []
if args.reg_type == 'fea_map_w':
    for fea_size, channels in fea_map_sizes:
        model = AttentionMap(fea_size, channels)
        model = model.to(device)
        optimizer = optim.SGD(model.parameters(), lr = args.att_lr, momentum = 0.9, weight_decay = 1e-4)
        decay_epochs = int(6000 * batch_size / dataset_sizes['train']) + 1
        if args.lr_scheduler == 'steplr':
            decay_lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size = decay_epochs, gamma = 0.1)
        elif args.lr_scheduler == 'explr':
            decay_lr_scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma = math.exp(math.log(0.1) / decay_epochs))
        attention_models.append((model, optimizer, decay_lr_scheduler))

confusion_matrix = meter.ConfusionMeter(num_classes)
def train_model(model, attmodels, criterion, optimizer, scheduler, num_epochs):
    since = time.time()
    for epoch in range(num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)
        confusion_matrix.reset()
        # Each epoch has a training and validation phase
        for phase in ['train', 'valid']:
            if phase == 'train':
                scheduler.step()
                model.train()  # Set model to training mode
                for m, _, lrsh in attmodels:
                    lrsh.step() 
                    m.train()
            else:
                model.eval()   # Set model to evaluate mode
                for m, _, _ in attmodels:
                    m.eval()

            running_loss = 0.0
            running_corrects = 0

            # Iterate over data.
            nstep = len(dataloaders[phase])
            for i, (inputs, labels) in enumerate(dataloaders[phase]):
                inputs = inputs.to(device)
                labels = labels.to(device)
                if args.data_aug == 'best' and phase == 'valid':
                    bs, ncrops, c, h, w = inputs.size()
                    inputs = inputs.view(-1, c, h, w)

                # zero the parameter gradients
                optimizer.zero_grad()
                for _, optm, _ in attmodels:
                    optm.zero_grad()
                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    if args.data_aug == 'best' and phase == 'valid':
                        outputs = outputs.view(bs, ncrops, -1).mean(1)
                    loss_main = criterion(outputs, labels)
                    loss_classifier = 0
                    loss_feature = 0
                    if not args.reg_type == 'l2':
                        loss_classifier = classifier_l2(model) 
                    if args.reg_type == 'l2_sp':
                        source_params = get_param_values(model_source)
                        loss_feature = param_l2_sp(model, source_params)
                    elif args.reg_type == 'fea_map':
                        loss_feature = feature_map_l2_sp(inputs)
                    elif args.reg_type == 'fea_map_w':
                        loss_feature = attentioned_feature_map_l2_sp(inputs, attmodels)
                    loss = loss_main + 0.5 * alpha * loss_feature + 0.5 * beta * loss_classifier
 
                    _, preds = torch.max(outputs, 1)
                    confusion_matrix.add(preds.data, labels.data)
                    if phase == 'train' and  i % 10 == 0:
                        corr_sum = torch.sum(preds == labels.data)
                        step_acc = corr_sum.double() / len(labels)
                        print('step: %d/%d, loss = %.4f(%.4f, %.4f, %.4f), top1 = %.4f' %(i, nstep, loss, loss_main, 0.5 * alpha * loss_feature, 0.5 * beta * loss_classifier, step_acc))

                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()
                        for _, optm, _ in attmodels:
                            optm.step()
                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)
                    
                layer_outputs_source.clear()
                layer_outputs_target.clear()

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print('{} epoch: {:d} Loss: {:.4f} Acc: {:.4f}'.format(
                phase, epoch, epoch_loss, epoch_acc))
            time_elapsed = time.time() - since
            print('Training complete in {:.0f}m {:.0f}s'.format(
                time_elapsed // 60, time_elapsed % 60))
            if epoch == num_epochs - 1:
                print('{} epoch: last Loss: {:.4f} Acc: {:.4f}'.format(
                    phase, epoch_loss, epoch_acc))

            print(confusion_matrix.value())
            if phase == 'train' and abs(epoch_loss) > 1e8:
                break
            if epoch >= 10 and epoch % 10 == 0 and args.save_model != '':
                torch.save(model_target, '%s.%d' % (args.save_model, epoch)) 
            # deep copy the model
        print()
        #torch.save(model_target.state_dict(), './model.cub.%d' % epoch)

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(
        time_elapsed // 60, time_elapsed % 60))
    # load best model weights
    return model
       
if args.reg_type == 'l2':
    optimizer_ft = optim.SGD(filter(lambda p: p.requires_grad, model_target.parameters()),
                        lr=args.lr_init, momentum=0.9, weight_decay = 1e-4)
else:
    optimizer_ft = optim.SGD(filter(lambda p: p.requires_grad, model_target.parameters()),
                        lr=args.lr_init, momentum=0.9)

num_epochs = int(9000 * batch_size / dataset_sizes['train']) 
decay_epochs = int(6000 * batch_size / dataset_sizes['train']) + 1
print('StepLR step_size = %d' % decay_epochs)

if args.lr_scheduler == 'steplr':
    lr_decay = optim.lr_scheduler.StepLR(optimizer_ft, step_size=decay_epochs, gamma=0.1)
elif args.lr_scheduler == 'explr':
    lr_decay = optim.lr_scheduler.ExponentialLR(optimizer_ft, gamma = math.exp(math.log(0.1) / decay_epochs))

criterion = nn.CrossEntropyLoss()
train_model(model_target, attention_models, criterion, optimizer_ft, lr_decay,
                       num_epochs = num_epochs)

if args.save_model != '':
    torch.save(model_target, args.save_model)
    for i, (m, _, _) in enumerate(attention_models):
        torch.save(m, args.save_model + '.att%d' % i)

