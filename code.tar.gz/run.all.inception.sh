#!/bin/bash

#for alpha in 0.0001 0.0002 0.0005 0.001 0.002 0.004 0.005 0.006 0.008 0.01; do
#for alpha in 0.001 0.002 0.005 0.01 0.02; do
for alpha in 0.001 0.002 0.005 0.01 0.02; do
for reg in fea_map_w l2_sp; do
#for reg in fm_cosine_att fm_euclid_att distri; do
for lr in 0.01; do
for da in best; do
for lrs in explr; do
#for data in food101; do
#for data in Caltech60; do
#for data in Caltech30 Caltech60 Stanford_Dogs indoorCVPR_09; do
for data in Caltech30 Stanford_Dogs; do
  if [ "$data" == "indoorCVPR_09" ]; then
    base="resnet50"
  else
    base="inceptionv4"
  fi
  pt="7h1x"
  param="--image_size=299 --lr_scheduler=$lrs --batch_size=32 --base_model=$base --data_dir=/mnt/data/lixingjian/benchmark/$data --reg_type=$reg --alpha=$alpha --lr_init=$lr  --data_aug=$da" 
  suffix="$reg.lr$lr.alpha$alpha.da$da.$lrs "
  bash run.one.sh $data "$param" $suffix $pt
done
done
done
done
done
done
