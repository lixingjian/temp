#!/bin/bash

i=1
reg="fea_map"

datadir="/mnt/data/lixingjian/benchmark"
run(){
    da="$1"
    data="$2"
    pt="$3"
    alpha="$4"
    if [ "$data" == "indoorCVPR_09" ]; then
        base="resnet50"
        bs=48
    else
        base="resnet101"
        bs=64
    fi
    if [ "$da" == "best" ]; then
        bs=48
    fi
    bash run.one.sh $data "--alpha=$alpha --batch_size=$bs --base_model=$base --data_dir=$datadir/$data --reg_type=$reg --data_aug=$da $save_model" "$reg.$da.$i" $pt "s_$reg"
}

da="normal"
#run $da "Stanford_Dogs" 7h1x 0.1
#run $da "Caltech30" 7h1x 0.02
run $da "Caltech60" 7h1x 0.02
#run $da "indoorCVPR_09" 7h1x 0.02

da="best"
#run $da "Stanford_Dogs" 6d1 0.1
#run $da "Caltech30" 6d1 0.02
#run $da "Caltech60" 6d1 0.02
#run $da "indoorCVPR_09" 7h1x 0.02
