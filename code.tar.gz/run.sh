#!/bin/sh

#!/bin/bash
envdir=/mnt/home/lixingjian/mqy/conda/miniconda2/envs/pytorch
libdir=/mnt/home/lixingjian/tool

export PATH=$envdir/bin:$PATH
export LD_LIBRARY_PATH=$envdir/lib:$libdir/cuda-8.0/lib64:$libdir/cudnn_v6.0/cuda/lib64:$LD_LIBRARY_PATH
python -u $*
