import sys

i = 0
out = ''
while True:
    try:
        buf = raw_input().rstrip()
    except:
        break
    x = i * 188 
    y = buf.split(':')[-1].strip()
    out += '(%d,%s)' % (x, y)
    i += 1
    
print(out)
