if [ "$1" == "" ]; then
    echo "no task name"
    exit
fi

squeue -u lixingjian |grep "$1" |sed 's/\s\+/ /g' |cut -f 2 -d' ' |xargs -i scancel  {}

