import numpy as np
import torch
from torch import nn
from torch.autograd import Variable
import pytorch_fft.fft.autograd as afft

class CountSketch:
    def __init__(self, input_dim, output_dim):
        self.input_dim = input_dim
        self.output_dim = output_dim
        rand_h = np.random.randint(output_dim, size=self.input_dim)
        rand_s = 2 * np.random.randint(2, size=self.input_dim) - 1
        self.sparse_sketch_matrix = Variable(self.generate_sketch_matrix(
                                            rand_h, rand_s, self.output_dim)).cuda()
    
    def __call__(self, bottom_flat):
        sketch = bottom_flat.mm(self.sparse_sketch_matrix) 
        return sketch        
    
    @staticmethod
    def generate_sketch_matrix(rand_h, rand_s, output_dim):

        # Generate a sparse matrix for tensor count sketch
        rand_h = rand_h.astype(np.int64)
        rand_s = rand_s.astype(np.float32)
        assert(rand_h.ndim == 1 and rand_s.ndim ==
               1 and len(rand_h) == len(rand_s))
        assert(np.all(rand_h >= 0) and np.all(rand_h < output_dim))

        input_dim = len(rand_h)
        indices = np.concatenate((np.arange(input_dim)[..., np.newaxis],
                                  rand_h[..., np.newaxis]), axis=1)
        indices = torch.from_numpy(indices)
        rand_s = torch.from_numpy(rand_s)
        sparse_sketch_matrix = torch.sparse.FloatTensor(
            indices.t(), rand_s, torch.Size([input_dim, output_dim]))
        return sparse_sketch_matrix.to_dense()

class KernelPooling(nn.Module):
    def __init__(self, input_dim, output_dim, p_order):
        super(KernelPooling, self).__init__()
        assert p_order >= 2
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.p_order = p_order
        self.ctsks = [CountSketch(input_dim, output_dim) for _ in range(p_order)]
        self.alphas = [nn.Parameter(torch.randn(1, 1)), nn.Parameter(torch.randn(1, input_dim).cuda())]
        for i in range(2, p_order + 1):
            self.alphas.append(nn.Parameter(torch.randn(1, output_dim).cuda()))

    def forward(self, bottom):        
        assert bottom.size(1) == self.input_dim
        batch_size, _, height, width = bottom.size()
        bottom_flat = bottom.permute(0, 2, 3, 1).contiguous().view(-1, self.input_dim)
        alpha_const = torch.ones((bottom_flat.shape[0], 1)) * self.alphas[0]
        feature_1st = bottom_flat * self.alphas[1]
        feature_out = torch.cat((alpha_const.cuda(), feature_1st), 1)
        sketch_pre = self.ctsks[0](bottom_flat)
        fft_real_pre, fft_imag_pre = afft.Fft()(sketch_pre, Variable(torch.zeros(sketch_pre.size())).cuda())
        for i in range(2, self.p_order + 1):
            sketch_cur = self.ctsks[i - 1](bottom_flat)
            fft_real_cur, fft_imag_cur = afft.Fft()(sketch_cur, Variable(torch.zeros(sketch_cur.size())).cuda())

            temp_rr, temp_ii = fft_real_pre.mul(fft_real_cur), fft_imag_pre.mul(fft_imag_cur)
            fft_real_pre, fft_imag_pre = temp_rr, temp_ii

            fft_product_real = temp_rr - temp_ii
            fft_product_imag = temp_rr + temp_ii

            cbp_flat = afft.Ifft()(fft_product_real, fft_product_imag)[0]
            cbp = cbp_flat.view(batch_size, height, width, self.output_dim)
            cbp = cbp.sum(dim=1).sum(dim=1).cuda()
            cbp = cbp * self.alphas[i]
            feature_out = torch.cat((feature_out, cbp), 1)
        
        return feature_out

if __name__ == '__main__':

    bottom1 = Variable(torch.randn(64, 2048, 1, 1)).cuda()

    layer = KernelPooling(2048, 4000, 4)
    layer.cuda()
    layer.train()

    out = layer(bottom1)
    print(out.shape)
