# -*- coding: utf-8 -*-
from __future__ import print_function, division

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import torch.nn.functional as F
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
import time
import sys
import os
import copy
import argparse

parser = argparse.ArgumentParser(description = 'finetuning')
parser.add_argument('--data_name')
parser.add_argument('--fea_size', type = int, default = 8000)
parser.add_argument('--fea_mix_order', type = int, default = 4)
parser.add_argument('--norm_type', choices = ['none', 'paper', 'bn'], default = 'bn')
parser.add_argument('--lr_init', type = float, default = 0.002)
parser.add_argument('--lr_strategy', choices = ['step7', 'exp0.8'], default = 'exp0.8')
args = parser.parse_args()  

print(args)

DATA_NAME = args.data_name
data_dir = '/mnt/data/lixingjian/case/%s.split' % DATA_NAME
BATCH_SIZE = 128
IMAGE_SIZE = 299

data_transforms = {
    'train': transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor()
    ]),
    'valid': transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor()
    ]),
}

image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x),
                                          data_transforms[x])
                  for x in ['train', 'valid']}
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=BATCH_SIZE,
                                             shuffle=True, num_workers=4)
              for x in ['train', 'valid']}
dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'valid']}
class_names = image_datasets['train'].classes
NUM_CLASSES = len(class_names)

device = torch.device("cuda:0")
#device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def train_model(model, criterion, optimizer, scheduler, num_epochs=25):
    since = time.time()

    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0

    for epoch in range(num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)

        # Each epoch has a training and validation phase
        for phase in ['train', 'valid']:
            if phase == 'train':
                scheduler.step()
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            running_loss = 0.0
            running_corrects = 0

            # Iterate over data.
            nstep = len(dataloaders[phase])
            for i, (inputs, labels) in enumerate(dataloaders[phase]):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    if phase == 'train':
                        outputs, aux = model(inputs)
                    else:
                        outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)
                    if phase == 'train' and  i % 10 == 0:
                        corr_sum = torch.sum(preds == labels.data)
                        step_acc = corr_sum.double() / len(labels)
                        print('step: %d/%d, loss = %.4f, top1 = %.4f' %(i, nstep, loss, step_acc))

                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print('{} epoch: {:d} Loss: {:.4f} Acc: {:.4f}'.format(
                phase, epoch, epoch_loss, epoch_acc))
            time_elapsed = time.time() - since
            print('Training complete in {:.0f}m {:.0f}s'.format(
                time_elapsed // 60, time_elapsed % 60))

            # deep copy the model
            if phase == 'valid' and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = copy.deepcopy(model.state_dict())

        print()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(
        time_elapsed // 60, time_elapsed % 60))
    print('Best val Acc: {:4f}'.format(best_acc))

    # load best model weights
    model.load_state_dict(best_model_wts)
    return model

#model_ft = models.resnet18(pretrained=True)
model_ft = models.inception_v3(pretrained = True)
for name, module in model_ft.named_children():
    if name.startswith('AuxLogits') or name.startswith('Conv2d') or name.startswith('Mixed_5'):
        #print(name, module)
        for param in module.parameters():
            param.requires_grad = False

num_ftrs = model_ft.fc.in_features

from CompactBilinearPooling import CompactBilinearPooling
from KernelPooling import KernelPooling
class FeatureInteractive(nn.Module):
    def __init__(self, num_ftrs, out_dim):
        super(FeatureInteractive, self).__init__()
        p_order = args.fea_mix_order
        if p_order < 2:
            self.cbp = CompactBilinearPooling(num_ftrs, num_ftrs, out_dim)
        else:
            self.cbp = KernelPooling(num_ftrs, out_dim, p_order)
            out_dim = 1 + num_ftrs + (p_order - 1) * out_dim
        self.cbp.cuda()
        self.cbp.train()
        self.bn = nn.BatchNorm1d(out_dim)
        self.fc = nn.Linear(out_dim, NUM_CLASSES)
        self.num_ftrs = num_ftrs
        self.out_dim = out_dim

    def forward(self, x):
        x = torch.reshape(x, (-1, self.num_ftrs, 1, 1))
        if args.fea_mix_order < 2:
            x1 = x.cuda()
            x = self.cbp(x.cuda(), x1)
        else:
            x = self.cbp(x.cuda())
        if args.norm_type == 'bn':
            x = self.bn(x)
        elif args.norm_type == 'paper':
            x = torch.sign(x) * torch.pow(torch.abs(x), 0.5)
            x = F.normalize(x, p = 2, dim = 1)
        x = self.fc(x)
        return x

#model_ft.fc = nn.Linear(num_ftrs, NUM_CLASSES)
model_ft.fc = FeatureInteractive(num_ftrs, args.fea_size)

model_ft = model_ft.to(device)

criterion = nn.CrossEntropyLoss()

# Observe that all parameters are being optimized
optimizer_ft = optim.Adagrad(filter(lambda p: p.requires_grad, model_ft.parameters()), lr=args.lr_init)

if args.lr_strategy == 'step7':
    exp_lr_scheduler = lr_scheduler.StepLR(optimizer_ft, step_size=7, gamma=0.1) # Decay LR by a factor of 0.1 every 7 epochs
elif args.lr_strategy == 'exp0.8':
    exp_lr_scheduler = lr_scheduler.ExponentialLR(optimizer_ft, gamma = 0.8)    #multiplied by 0.1 every 10 epochs

model_ft = train_model(model_ft, criterion, optimizer_ft, exp_lr_scheduler,
                       num_epochs=10)

