#!/bin/bash
if [ ! -d log ]; then
    mkdir log
else
    if [ -f log/srun.out ]; then
	rm log/srun.out
    fi
    if [ -f log/debug.out ]; then
	rm log/debug.out
    fi
fi

srun -J debug           \
     -o log/debug.out   \
     -e log/debug.out   \
     -p 1080Ti_dbg      \
     -c 8               \
     --gres=gpu:1       \
     bash run.sh $*     \
     >log/srun.out      \
     2>&1 &
