# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import sys
import math
import subprocess
import collections
import multiprocessing

import numpy as np
import tensorflow as tf
from absl import app
from absl import flags

import rl
import utils


FLAGS = flags.FLAGS

flags.DEFINE_string("partitions", None,
                    "partitions")
flags.DEFINE_string("logdir", "log",
                    "logging directory")

flags.DEFINE_integer("num_workers", 200,
                     "number of workers")
flags.DEFINE_integer("num_nodes", 10,
                     "number of nodes")
flags.DEFINE_integer("num_tokens", 10,
                     "number of tokens")
flags.DEFINE_integer("batch_size", 10,
                     "batch size")
flags.DEFINE_integer("num_models", 24000,
                     "maximum number of models sampled")
flags.DEFINE_integer("early_stop", 20,
                     "early stop")


def supervisor(q, mid):
    fout = os.path.join(FLAGS.logdir, "nohup", "%d.out" % mid)
    ferr = os.path.join(FLAGS.logdir, "nohup", "%d.err" % mid)
    if FLAGS.partitions:
        parts = FLAGS.partitions
    else:
        parts = [
            "TitanXx8_slong",
            "TitanXx8_short",
            "TitanXx8",
            "M40x8",
            "M40x8_slong",
            "M40x8_short",
            "P100",
        ]
        parts = ",".join(parts)

    cmd = ("srun -J cell -o %s -e %s -p %s -c 5 --gres=gpu:1 "
           "bash run.sh trainer.py --mid=%d --early_stop=%d") % \
          (fout, ferr, parts, mid, FLAGS.early_stop)
    while True:
        try:
            subprocess.check_call(cmd, shell=True)
            break
        except subprocess.CalledProcessError as e:
            print("[%s] training model #%d exits with exit code %d" % \
                  (utils.stime(), mid, e.returncode), file=sys.stderr)

    q.put((mid, utils.load_reward(mid)))


def main(_):
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    utils.prepare()
    utils.prepare("actions")
    utils.prepare("rewards")
    utils.prepare("nohup")
    utils.prepare("checkpoints")

    controller = rl.Controller(
        FLAGS.num_nodes,
        FLAGS.num_tokens,
        FLAGS.batch_size,
        os.path.join(FLAGS.logdir, "summary"),
    )

    save_path = os.path.join(FLAGS.logdir, "checkpoints", "controller")
    if tf.train.checkpoint_exists(save_path):
        controller.restore(save_path)
        print("[%s] controller restored" % utils.stime())
    else:
        print("[%s] controller initialized" % utils.stime())
    i = controller.step * FLAGS.batch_size

    buff = collections.deque()
    num_jobs = min(FLAGS.num_workers, FLAGS.num_models - i)
    for _ in range(int(math.ceil(num_jobs / FLAGS.batch_size))):
        tokens, adjvec = controller.sample()
        for action in zip(*controller.sample()):
            utils.dump_action(i, action)
            buff.append(i)
            i += 1

    q = multiprocessing.Queue()
    for _ in range(num_jobs):
        mid = buff.popleft()
        multiprocessing.Process(target=supervisor, args=(q, mid)).start()

    actions, rewards = [], []
    while multiprocessing.active_children() or not q.empty():
        mid, reward = q.get()
        if not np.isnan(reward):
            actions.append(utils.load_action(mid))
            rewards.append(reward)

        if not buff and i < FLAGS.num_models:
            for action in zip(*controller.sample()):
                utils.dump_action(i, action)
                buff.append(i)
                i += 1

        if buff:
            mid = buff.popleft()
            multiprocessing.Process(target=supervisor, args=(q, mid)).start()

        if len(rewards) == FLAGS.batch_size:
            print("[%s] step = %d, average accuracy = %.3f" % \
                  (utils.stime(), controller.step, np.mean(rewards)))

            actions_to, actions_ad = zip(*actions)
            rewards = list(map(lambda x: x ** 3, rewards))

            controller.update(actions_to, actions_ad, rewards)
            controller.save(save_path)

            actions, rewards = [], []

    print("[%s] jobs done" % utils.stime())


if __name__ == "__main__":
    app.run(main)
