#!/bin/bash
source /tools/lm-venv/py3.6.1-tf-1.5.0rc0-svail/bin/activate_and_save
export PYTHONPATH=$pwd:$PYTHONPATH

python -u $*
