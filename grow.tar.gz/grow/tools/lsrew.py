# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import pickle
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--logdir", type=str, default="log")
    args = parser.parse_args()

    reward_dir = os.path.join(args.logdir, "rewards")
    for f in os.listdir(reward_dir):
        mid, _ = os.path.splitext(f)
        try:
            reward = pickle.load(open(os.path.join(reward_dir, f), "rb"))
        except EOFError:
            continue
        print("%s %.3f" % (mid, reward))


if __name__ == "__main__":
    main()
