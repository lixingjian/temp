# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import time
import pickle

import numpy as np
import tensorflow as tf
from absl import app
from absl import flags

import nn
# from build import vgg
# from build import resnet
# from build import resnext
from build import inception
import utils


FLAGS = flags.FLAGS

flags.DEFINE_string("train_path", "../cifar-10/data*",
                    "path to training data")
flags.DEFINE_string("test_path", "../cifar-10/test*",
                    "path to testing data")
flags.DEFINE_string("logdir", "./log",
                    "logging directory")

flags.DEFINE_integer("mid", 23000,
                     "model id")
flags.DEFINE_integer("no", 1,
                     "training no")

flags.DEFINE_float("time_limit", 143,
                   "time limit")

chunk_size = 5000


def main(_):
    train_files = tf.gfile.Glob(FLAGS.train_path)
    test_files = tf.gfile.Glob(FLAGS.test_path)

    tokens, adjvec = utils.load_action(FLAGS.mid)

    model = nn.Model(inception.net, tokens, adjvec, train_files, test_files)
    total_params = np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()])
    print("[%s] computation graph built. total params = %.1fm" % (utils.stime(), total_params / 1e6))

    save_dir = os.path.join(FLAGS.logdir, "grow", str(FLAGS.no))
    save_path = os.path.join(save_dir, "model")
    if not os.path.exists(save_dir):
        os.mkdir(save_dir)
    else:
        if tf.train.checkpoint_exists(save_path):
            model.restore(save_path)
    
    max_step = chunk_size * len(train_files) * FLAGS.T_0 // FLAGS.batch_size
    best, t0 = 0.0, time.time()
    time_limit = FLAGS.time_limit * 60 * 60
    while model.step < max_step:
        loss, accuracy = model.update()

        if model.step % 100 == 0:
            format_str = "[%s] step = %d, loss = %.4f, train acc. = %.4f"
            print(format_str % (utils.stime(), model.step, loss, accuracy))

        if model.step % 2000 == 0:
            accuracy = model.test()
            best = max(accuracy, best)
            format_str = "[%s] checkpoint: test acc. = %.4f (best acc. = %.4f)"
            print(format_str % (utils.stime(), accuracy, best))

        if model.step % 10000 == 0:
            model.save(save_path)

        if time.time() > t0 + time_limit:
            break

    model.save(save_path)

    accuracy = model.test()
    best = max(accuracy, best)
    format_str = "[%s] jobs done. test acc. = %.4f (best acc. = %.4f)"
    print(format_str % (utils.stime(), accuracy, best))


if __name__ == "__main__":
    app.run(main)
