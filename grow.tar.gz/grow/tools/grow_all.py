# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import subprocess

def main():
    prefix = ("srun -J grow.2 -o log/grow.2/%d.out -e log/grow.2/%d.out "
              "-p TitanXx8,M40x8,P100 -c 5 --gres=gpu:1 "
              "bash run.sh tools/grow_one.py --no=%d ")
    config = [
        "",
        "--weight_decay=0.00005 ",
        "--weight_decay=0.00015 ",
    ]
    suffix = "--time_limit=6.5 >log/srun.out 2>&1 &"
    for i in range(len(config)):
        cmd = prefix + config[i] + suffix
        cmd = cmd % (i, i, i)
        print(cmd)
        subprocess.call(cmd, shell=True)


if __name__ == "__main__":
    main()
