#!/bin/bash
job=$1

scancel $( squeue | grep "$job" | awk '{print $1}' )
