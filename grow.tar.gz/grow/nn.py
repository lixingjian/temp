# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math

import numpy as np
import tensorflow as tf
from absl import flags

import preprocess


FLAGS = flags.FLAGS

flags.DEFINE_float("lr_max", 0.025,
                   "initial learning rate")
flags.DEFINE_float("lr_min", 0.0001,
                   "limiting learning rate")
# flags.DEFINE_float("lr_decay", 0.94,
#                    "lr decay rate")
flags.DEFINE_float("gd_clip", 5.0,
                   "gradient clipping")

# flags.DEFINE_integer("num_epochs_per_decay", 2,
#                      "number of epochs per decay")
flags.DEFINE_integer("batch_size", 32,
                     "batch size")
flags.DEFINE_integer("T_0", 600,
                     "number of epochs")

chunk_size = 5000


class Model(object):
    def __init__(self, build_fn, tokens, adjvec, train_files, test_files, valid_files=None):
        with tf.device("/cpu:0"):
            train_iter = preprocess.iterator(train_files, FLAGS.batch_size, training=True)
            test_iter = preprocess.iterator(test_files, FLAGS.batch_size, training=False)
            if valid_files is not None:
                valid_iter = preprocess.iterator(valid_files, FLAGS.batch_size, training=False)

            handle = tf.placeholder(tf.string, shape=[])
            input_iter = tf.data.Iterator.from_string_handle(
                handle,
                train_iter.output_types,
                train_iter.output_shapes,
            )
            images, labels = input_iter.get_next()

        training = tf.equal(handle, train_iter.string_handle())
        loss, accuracy = build_fn(images, labels, training, tokens, adjvec)

        lr = tf.constant(FLAGS.lr_max, dtype=tf.float32)
        optimizer = tf.train.MomentumOptimizer(lr, 0.9, use_nesterov=True)
        # optimizer = tf.train.RMSPropOptimizer(lr, momentum=0.9, epsilon=1.0)
        step = tf.train.create_global_step()

        extra_update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(extra_update_ops):
            grads_and_vars = optimizer.compute_gradients(loss)
            grads_and_vars = [(tf.clip_by_value(grad, -FLAGS.gd_clip, FLAGS.gd_clip), var) for grad, var in grads_and_vars]
            update_op = optimizer.apply_gradients(grads_and_vars, step)

        saver = tf.train.Saver()

        sess = tf.Session()

        _, train_handle, test_handle = sess.run([
            tf.global_variables_initializer(),
            train_iter.string_handle(),
            test_iter.string_handle(),
        ])

        max_step = chunk_size * len(train_files) * FLAGS.T_0 // FLAGS.batch_size
        # decay_step = chunk_size * len(train_files) * FLAGS.num_epochs_per_decay // FLAGS.batch_size
        test_batch = chunk_size * len(test_files) // FLAGS.batch_size

        if valid_files is not None:
            valid_handle = sess.run(valid_iter.string_handle())
            valid_batch = chunk_size * len(valid_files) // FLAGS.batch_size

        def cosine_annealing(step):
            frac = (1 + math.cos(step / max_step * math.pi)) / 2
            return FLAGS.lr_min + (FLAGS.lr_max - FLAGS.lr_min) * frac

        # def plateau_annealing(step):
        #     return 0.1   if step < 0.4 * max_step else \
        #            0.01  if step < 0.6 * max_step else \
        #            0.001 if step < 0.8 * max_step else \
        #            0.0001

        # def exponential_decay(step):
        #     return FLAGS.lr_max * FLAGS.lr_decay ** (step // decay_step)

        def update():
            feed_dict = {handle: train_handle, lr: cosine_annealing(self.step)}
            _, loss_val, acc_val, self.step = sess.run([update_op, loss, accuracy, step], feed_dict)
            return loss_val, acc_val

        def evaluate(eval_handle, eval_batch):
            def func():
                feed_dict = {handle: eval_handle}
                return np.mean([sess.run(accuracy, feed_dict) for _ in range(eval_batch)])
            return func

        def save(save_path):
            saver.save(sess, save_path)

        def restore(save_path):
            saver.restore(sess, save_path)
            self.step = sess.run(step)

        self.step = 0

        self.update = update
        self.test = evaluate(test_handle, test_batch)
        self.save = save
        self.restore = restore
        if valid_files is not None:
            self.validate = evaluate(valid_handle, valid_batch)
