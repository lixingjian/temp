# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from absl import flags


FLAGS = flags.FLAGS

flags.DEFINE_boolean("random_flip_left_right", True,
                     "random flip left and right")
flags.DEFINE_boolean("random_flip_up_down", False,
                     "random flip up and down")
flags.DEFINE_boolean("random_brightness", False,
                     "randomly adjust brightness")
flags.DEFINE_boolean("random_contrast", False,
                     "randomly adjust contrast")
flags.DEFINE_boolean("random_hue", False,
                     "randomly adjust hue")
flags.DEFINE_boolean("random_saturation", False,
                     "randomly adjust saturation")
flags.DEFINE_boolean("cutout", True,
                     "cutout")

chunk_size = 5000

image_size = 32
image_depth = 3
num_classes = 10

half_length = 8


def iterator(files, batch_size, training):
    num_chunks = len(files)
    dataset = tf.data.Dataset.from_tensor_slices(files).apply(
        tf.contrib.data.parallel_interleave(tf.data.TFRecordDataset, num_chunks))

    if training:
        min_queue_examples = int(0.4 * chunk_size * num_chunks)
        dataset = dataset.apply(tf.contrib.data.shuffle_and_repeat(
            min_queue_examples + 3 * batch_size))
    else:
        dataset = dataset.repeat()

    dataset = dataset.apply(tf.contrib.data.map_and_batch(
        lambda example: parse(example, training), batch_size))

    dataset = dataset.prefetch(1)

    return dataset.make_one_shot_iterator()


def parse(example, training):
    features = tf.parse_single_example(
        example,
        features={
            "image": tf.FixedLenFeature([], tf.string),
            "label": tf.FixedLenFeature([], tf.int64)
        })

    image = tf.decode_raw(features["image"], tf.uint8)
    image = tf.cast(image, tf.float32)
    image = tf.reshape(image, [image_depth, image_size, image_size])

    image = tf.transpose(image, [1, 2, 0])
    image = preprocess(image, training)
    image = tf.transpose(image, [2, 0, 1])

    label = tf.cast(features["label"], tf.int32)
    label = tf.one_hot(label, num_classes)

    return image, label


def preprocess(image, training):
    if training:
        image = augment(image)
    image = tf.image.per_image_standardization(image)
    if training and FLAGS.cutout:
        center = tf.random_uniform(shape=[2], maxval=image_size, dtype=tf.int32)
        offset_width = tf.maximum(0, center[0] - half_length)
        offset_height = tf.maximum(0, center[1] - half_length)
        target_width = tf.minimum(center[0] + half_length, image_size) - offset_width
        target_height = tf.minimum(center[1] + half_length, image_size) - offset_height

        patch = tf.image.crop_to_bounding_box(image, offset_height, offset_width, target_height, target_width)
        patch = tf.image.pad_to_bounding_box(patch, offset_height, offset_width, image_size, image_size)

        image -= patch

    return image


def augment(image):
    image = tf.image.resize_image_with_crop_or_pad(image, image_size+4, image_size+4)
    image = tf.random_crop(image, [image_size, image_size, 3])
    if FLAGS.random_flip_left_right:
        image = tf.image.random_flip_left_right(image)
    if FLAGS.random_flip_up_down:
        image = tf.image.random_flip_up_down(image)
    if FLAGS.random_brightness:
        image = tf.image.random_brightness(image, max_delta=0.3)
    if FLAGS.random_contrast:
        image = tf.image.random_contrast(image, lower=0.2, upper=1.8)
    if FLAGS.random_hue:
        image = tf.image.random_hue(image, max_delta=0.2)
    if FLAGS.random_saturation:
        image = tf.image.random_saturation(image, lower=0.5, upper=1.5)

    return image
