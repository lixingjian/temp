# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import numpy as np
import tensorflow as tf
from absl import app
from absl import flags

import nn
# from build import vgg
# from build import resnet
# from build import resnext
from build import inception
import utils


FLAGS = flags.FLAGS

flags.DEFINE_string("data_path", "../cifar-10/data*",
                    "data path")
flags.DEFINE_string("logdir", "log",
                    "logging directory")

flags.DEFINE_integer("mid", 0,
                     "model id")
flags.DEFINE_integer("early_stop", 20,
                     "early stop")

chunk_size = 5000


def main(_):
    train_files = tf.gfile.Glob(FLAGS.data_path)
    test_files = [np.random.choice(train_files)]
    train_files.remove(*test_files)

    tokens, adjvec = utils.load_action(FLAGS.mid)

    model = nn.Model(inception.net, tokens, adjvec, train_files, test_files)
    early_stop = chunk_size * len(train_files) * FLAGS.early_stop // FLAGS.batch_size

    while model.step < early_stop:
        loss, accuracy = model.update()

        if np.isnan(loss):
            format_str = "[%s] jobs done, step = %d, loss = nan"
            print(format_str % (utils.stime(), model.step))
            break

        if model.step % 100 == 0:
            format_str = "[%s] step = %d, loss = %.3f, train acc. = %.3f"
            print(format_str % (utils.stime(), model.step, loss, accuracy))
    else:
        accuracy = model.test()
        format_str = "[%s] jobs done, step = %d, valid acc. = %.3f"
        print(format_str % (utils.stime(), model.step, accuracy))

    utils.dump_reward(FLAGS.mid, accuracy)


if __name__ == "__main__":
    app.run(main)
