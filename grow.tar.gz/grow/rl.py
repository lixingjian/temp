# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import numpy as np
import tensorflow as tf
from absl import flags


FLAGS = flags.FLAGS

flags.DEFINE_integer("num_layers", 2,
                     "number of LSTM layers")
flags.DEFINE_integer("num_units", 64,
                     "number of units in LSTM cell")

flags.DEFINE_float("edge_prob", 0.1,
                   "probability of an edge being included in the graph")
flags.DEFINE_float("tanh_c", 2.5,
                   "tanh constant")
flags.DEFINE_float("temper", 5.0,
                   "sample temperature")

flags.DEFINE_float("lr", 0.001,
                   "learning rate")
# flags.DEFINE_float("ent_coef", 0.0001,
#                    "entropy penalty coefficient")
# flags.DEFINE_float("kl_coef", 0.0001,
#                    "kl divergence penalty coefficient")
flags.DEFINE_float("bl_decay", 0.9,
                   "baseline moving average decay rate")


def build_rnn(inputs, num_nodes, num_tokens):
    def rnn_cell():
        return tf.nn.rnn_cell.LSTMCell(
            FLAGS.num_units,
            initializer=tf.random_uniform_initializer(-0.1, 0.1))
    cell = tf.nn.rnn_cell.MultiRNNCell([rnn_cell() for _ in range(FLAGS.num_layers)])

    depth = max(num_nodes-1, num_tokens)
    he_initializer = tf.truncated_normal_initializer(stddev=np.sqrt(2.0/FLAGS.num_units))

    def encode_token(token):
        return tf.squeeze(tf.one_hot(token, depth), axis=1)

    def encode_adj(adj, step):
        paddings = tf.constant([[0, 0], [0, depth-step]])
        return tf.cast(tf.pad(adj, paddings), dtype=tf.float32)

    def decode_token(hidden):
        logits = tf.layers.dense(hidden, num_tokens, kernel_initializer=he_initializer)
        logits = FLAGS.tanh_c * tf.tanh(logits / FLAGS.temper)
        token = tf.multinomial(logits, 1)
        return token, tf.expand_dims(logits, 1)

    def decode_adj(hidden, step):
        logits = tf.layers.dense(hidden, step, kernel_initializer=he_initializer)
        logits = FLAGS.tanh_c * tf.tanh(logits / FLAGS.temper)

        pd = tf.distributions.Bernoulli(logits=logits)
        adj = pd.sample()

        p0 = tf.fill(tf.shape(logits), FLAGS.edge_prob)
        p0 = tf.distributions.Bernoulli(probs=p0)
        kl = tf.distributions.kl_divergence(pd, p0)

        return adj, logits, kl

    tokens, softmax, adjvec, sigmoid, kl_div = [], [], [], [], []

    def rnn_block(hidden, state):
        hidden, state = cell(hidden, state)
        token, logits = decode_token(hidden)

        tokens.append(token)
        softmax.append(logits)

        for step in range(1, num_nodes):
            hidden = encode_token(token)
            hidden, state = cell(hidden, state)
            adj, logits, kl = decode_adj(hidden, step)

            adjvec.append(adj)
            sigmoid.append(logits)
            kl_div.append(kl)

            hidden = encode_adj(adj, step)
            hidden, state = cell(hidden, state)
            token, logits = decode_token(hidden)

            tokens.append(token)
            softmax.append(logits)

        return token, state

    batch_size = tf.shape(inputs)[0]
    state = cell.zero_state(batch_size, dtype=tf.float32)

    hidden = encode_adj(inputs, 1)
    token, state = rnn_block(hidden, state)

    hidden = encode_token(token)
    token, state = rnn_block(hidden, state)

    tokens, softmax, adjvec, sigmoid, kl_div = map(
        lambda x: tf.concat(x, axis=1),
        [tokens, softmax, adjvec, sigmoid, kl_div])

    return tokens, softmax, adjvec, sigmoid, kl_div


def build_policy(tokens, softmax, adjvec, sigmoid, kl_div, rewards):
    tf.summary.histogram("rewards", rewards)

    ema = tf.train.ExponentialMovingAverage(FLAGS.bl_decay)
    with tf.control_dependencies([rewards]):
        ema_op = ema.apply([rewards])
    rewards -= ema.average(rewards)

    neglogp_to = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=tokens, logits=softmax)
    adjvec = tf.cast(adjvec, tf.float32)
    neglogp_ad = tf.nn.sigmoid_cross_entropy_with_logits(labels=adjvec, logits=sigmoid)
    neglogp = tf.reduce_sum(neglogp_to, axis=1) + tf.reduce_sum(neglogp_ad, axis=1)

    entropy = tf.reduce_mean(neglogp)
    tf.summary.scalar("entropy", entropy)

    kl_div = tf.reduce_mean(tf.reduce_sum(kl_div, axis=1))
    tf.summary.scalar("kl_diveregence", kl_div)

    loss = tf.reduce_mean(neglogp * rewards)
    # loss += FLAGS.ent_coef * entropy + FLAGS.kl_coef * kl_div
    tf.summary.scalar("loss", loss)

    step = tf.train.create_global_step()
    train_op = tf.train.AdamOptimizer(FLAGS.lr).minimize(loss, step)

    update_op = tf.group(ema_op, train_op)
    summary_op = tf.summary.merge_all()

    return update_op, summary_op, step


class Controller(object):
    def __init__(self, num_nodes, num_tokens, batch_size=10, logdir="log"):
        INPUTS = tf.placeholder(tf.float32, shape=[None, 1], name="inputs")
        TOKENS, SOFTMAX, ADJVEC, SIGMOID, KL_DIV = build_rnn(INPUTS, num_nodes, num_tokens)

        ACTIONS_TO = tf.placeholder(tf.int32, shape=[None, num_nodes * 2], name="actions_to")
        ACTIONS_AD = tf.placeholder(tf.int32, shape=[None, num_nodes * (num_nodes - 1)], name="actions_ad")
        REWARDS = tf.placeholder(tf.float32, shape=[None], name="rewards")

        UPDATE, SUMMARY, STEP = build_policy(ACTIONS_TO, SOFTMAX, ACTIONS_AD, SIGMOID, KL_DIV, REWARDS)

        saver = tf.train.Saver()
        summary_writer = tf.summary.FileWriter(logdir)

        sess = tf.Session(config=tf.ConfigProto(device_count={"GPU": 0}))
        rewards = np.zeros(batch_size)
        sess.run(tf.global_variables_initializer(), feed_dict={REWARDS: rewards})

        inputs = np.zeros([batch_size, 1])
        def sample():
            return sess.run([TOKENS, ADJVEC], feed_dict={INPUTS: inputs})

        def update(actions_to, actions_ad, rewards):
            feed_dict = {INPUTS: inputs, ACTIONS_TO: actions_to, ACTIONS_AD: actions_ad, REWARDS: rewards}
            _, summary, step = sess.run([UPDATE, SUMMARY, STEP], feed_dict=feed_dict)
            summary_writer.add_summary(summary, step)

            self.step = step

        def save(save_path):
            saver.save(sess, save_path)

        def restore(save_path):
            saver.restore(sess, save_path)

            self.step = sess.run(STEP)

        self.step = 0

        self.sample = sample
        self.update = update
        self.save = save
        self.restore = restore
