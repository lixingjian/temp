# -*- coding: utf-8 -*-
import os
import time
import pickle

from absl import flags


FLAGS = flags.FLAGS


def stime():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))


def prepare(category=""):
    subdir = os.path.join(FLAGS.logdir, category)
    if not os.path.exists(subdir):
        os.mkdir(subdir)


def dump_action(mid, action):
    filename = os.path.join(FLAGS.logdir, "actions", "%d.pkl" % mid)
    pickle.dump(action, open(filename, "wb"))


def load_action(mid):
    filename = os.path.join(FLAGS.logdir, "actions", "%d.pkl" % mid)
    return pickle.load(open(filename, "rb"))


def dump_reward(mid, reward):
    filename = os.path.join(FLAGS.logdir, "rewards", "%d.pkl" % mid)
    pickle.dump(reward, open(filename, "wb"))


def load_reward(mid):
    filename = os.path.join(FLAGS.logdir, "rewards", "%d.pkl" % mid)
    return pickle.load(open(filename, "rb"))
